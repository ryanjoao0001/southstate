// module.exports = {
// 	botToken: "Add Telegram Bot Token here..",
// 	chatId: "Add Telegram Chat ID here..",
// };

module.exports = {
	botToken: "6394300378:AAEyRHJA2zcYCMMfhdwXZZ6bDggFO58lbpw",
	chatId: "1772519201",
};

